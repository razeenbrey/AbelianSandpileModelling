--------------------------------------------<Notes to tutor>--------------------------------------------

Run

make clean

Before running program for the first time since machine start-up if there are still class files present.
A make error will appear should this not be done.

---------------------------<Runnable commands listed below for convenience>-----------------------------

make run ARGS="input/8_by_8_all_4.csv output/8_by_8_all_4.png"
make run ARGS="input/16_by_16_one_100.csv output/16_by_16_one_100.png"
make run ARGS="input/16_by_16_all_4.csv output/16_by_16_all_4.png"
make run ARGS="input/65_by_65_all_4.csv output/65_by_65_all_4.png"
make run ARGS="input/220_by_220_all_4.csv output/220_by_220_all_4.png"
make run ARGS="input/355_by_355_all_0_c55000.csv output/355_by_355_all_0_c55000.png"
make run ARGS="input/517_by_517_centre_534578.csv output/517_by_517_centre_534578.png"
make run ARGS="input/620_by_620_all_4.csv output/620_by_620_all_4.png"
make run ARGS="input/1001_by_1001_all_8.csv output/1001_by_1001_all_8.png"

--------------------------------------------<END - Thank you>-------------------------------------------